package com.b.ser;

public class ServiceLayer {
	

	public void deposit() {
		   
	   }
	
	public void fundTransfer() {
		
		
	}
	
 public void printTranscations() {
    	 
     }
 
 public void showBalance() {
 	
 }
 
 public void withdraw() {
	 
	 
 }
	
	
	
	
	
	
}
