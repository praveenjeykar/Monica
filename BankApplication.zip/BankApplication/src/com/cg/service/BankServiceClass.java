package com.cg.service;


import java.util.List;
import java.util.Scanner;

import com.cg.bean.BankDetails;
import com.cg.dao.BankDatabase;

public class BankServiceClass implements BankServiceInterface
{
	 
	Scanner sc=new Scanner(System.in);
	BankDetails bdetails=new BankDetails();
	BankDatabase database=new BankDatabase();
	public void createAccount()
	{
		System.out.print("Enter your name:");
		bdetails.setName(sc.next());
		System.out.print("Enter Adhaar details:");
		bdetails.setAdhaarNo(sc.next());
		System.out.print("Enter your Mobile Number:");
		bdetails.setMobileNumber(sc.next());
		bdetails.setAccountno();
		 System.out.println("set the pin to the account");
		 bdetails.setPin(sc.nextInt());
		System.out.println("Enter the amount to be deposited");
		bdetails.setBalance(sc.nextInt());
		System.out.println("Account created successfully");
		database.storeCustDetails(bdetails);
	}
   public BankDetails showBalance() {
		
	 
	   double i,accountno;
		int k;
		int pin;
		do{
		System.out.println("enter account no");
		 accountno = sc.nextDouble();
		i=database.checkAccountNo(accountno);
		}
		while(i==1);
		do{
		System.out.println("enter the pin");
		 pin=sc.nextInt();
		k=database.checkPin(pin);
		}
		while(k==1);
		return database.showAccountBalance(accountno,pin);
	}

	public void deposit()
	{
		
		double i,accountno;
		do{
		System.out.println("enter the account no");
		 accountno = sc.nextDouble();
		 i=database.checkAccountNo(accountno);
		}
		while(i==1);
		System.out.println("enter the amount to be depoist:");
		int amt = sc.nextInt();
		database.deposit(accountno, amt);	
		
	}

	public void withDraw() {
		double i,accountno;
		int pin;
		
		do{
		System.out.println("enter the account no");
		 accountno = sc.nextDouble();
		 i=database.checkAccountNo(accountno);
		}
		while(i==1);
		System.out.println("enter the amount to be withdrawn:");
		int amt = sc.nextInt();
		database.withDraw(accountno, amt);
		
	}

	public void fundTransfer() 
	{
		double i,accountno;
		
		do{
		System.out.println("enter the account number to which amount has to be credited:");
		 accountno = sc.nextDouble();
		 i=database.checkAccountNo(accountno);
		}
		while(i==1);
	do{
		System.out.println("enter the account number from where amount has to be debited:");
		 accountno = sc.nextDouble();
		i=database.checkAccountNo(accountno);
	}
	while(i==1);
		System.out.println("enter the amount to be transferred");
		int amt = sc.nextInt();
		double acctto = 0;
		database.fundTransfer(accountno, acctto, amt);
	}

	public List<String> printTransactions() {
		
		double i,accountno;
		BankDetails b=new BankDetails();
		do{
		System.out.println("enter the account no");
		 accountno = sc.nextDouble();
		 i=database.checkAccountNo(accountno);
		}
		while(i==1);
		
		return database.printTransction(accountno);
		}

	}


