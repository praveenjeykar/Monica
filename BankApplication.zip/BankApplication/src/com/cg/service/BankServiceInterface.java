package com.cg.service;

import java.util.List;

import com.cg.bean.BankDetails;

public interface BankServiceInterface
{
	public void createAccount();
	BankDetails showBalance();
	void deposit();
	void withDraw();
	 void fundTransfer();
	 List<String> printTransactions();

}
