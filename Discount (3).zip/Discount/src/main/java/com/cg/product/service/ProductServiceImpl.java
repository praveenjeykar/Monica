package com.cg.product.service;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.product.bean.Product;
import com.cg.product.dao.IProductDao;

@Service
public class ProductServiceImpl implements IProductService {
	@Autowired
IProductDao productdao;

	

		@Override
		public double CalDiscount(String prodId) {

			Product pro=productdao.getProductById(prodId);
		
		double remBal=pro.getPrice()-((pro.getDiscount()*pro.getPrice())/100);
		
	     return remBal;
		}

		
	
	
	}

